export const backendBaseURL = process.env.VUE_APP_STATIC_BASE_URL;
