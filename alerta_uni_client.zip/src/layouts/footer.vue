<template>
    <footer>
        <div class="flex justify-center items-center mt-10 mb-10">
            <div class="title">
                UFRRJ | Sistemas de Informação | Versão Beta
            </div>
        </div>
    </footer>
</template>

<script>
export default {
    name: 'Footer',
}
</script>

<style lang="scss" scoped>
.title {
    font-size: 14px;
    color: #707070;
}
</style>